const swaggerAutogen = require('swagger-autogen')();
import swaggerConfig from './config/swagger';

const outuput = '../swagger.json';
const ednpoints = ['./src/routes/index.ts'];

swaggerAutogen(outuput, ednpoints, swaggerConfig);