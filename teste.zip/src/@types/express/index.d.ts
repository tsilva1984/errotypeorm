declare namespace Express {
  export interface Request {
    userId: string;
    id_brand:string;
  }
}
