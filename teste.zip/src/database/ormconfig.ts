import dotenv from 'dotenv';
import path from 'path';
dotenv.config();

import { DataSource } from "typeorm";


//console.log(path.resolve(__dirname, "..","dist", "app", "entities", "*{.ts,.js}"),'caminho')

export const AppDataSource = new DataSource({
  type: "postgres",
  host: process.env.TYPEORM_HOST,
  port: parseInt(process.env.TYPEORM_PORT),
  username: process.env.TYPEORM_USERNAME,
  password: process.env.TYPEORM_PASSWORD,
  database: process.env.TYPEORM_DATABASE,

  entities: [path.resolve(__dirname, "..", "app", "entities", "*{.ts,.js}")],
  migrations: ["src/database/migrations/*{.ts,.js}"],
  subscribers: ["src/subscribers/**/*.ts"],
});

//prd   entities: [path.resolve(__dirname, "..","dist", "app", "entities", "*{.ts,.js}")],
//dev entities: [path.resolve(__dirname, "..", "app", "entities", "*{.ts,.js}")],





//original
//entities: ["src/app/*/entities/*{.ts,.js}"],
//migrations: ["src/database/migrations/*{.ts,.js}"],
//subscribers: ["src/subscribers/**/*.ts"],