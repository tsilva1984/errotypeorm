import "reflect-metadata"
import { AppDataSource } from "./ormconfig";

// Inicializar o DataSource
AppDataSource.initialize()
  .then(() => {
    console.log('Database OK')
  })
  .catch((error) => {
    console.error(error);
  });
