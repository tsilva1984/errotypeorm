import "reflect-metadata"
import "express-async-errors"
import express,{NextFunction,Request,Response} from "express";
import cors from "cors"
import swaggerUi from "swagger-ui-express"
import swaggerDocument from "../swagger.json"
import { AppDataSource } from "./database/ormconfig";
import { router } from "./routes";

const app = express();

/*
function authChecker(req, res, next) {
  if (req.headers.authorization === process.env.APP_TOKEN) {
      next();
  } else {
      res.status(401).json("unauthorized");
  }
}
*/

app.use(cors());
app.use(express.json());

//app.use(authChecker);

app.use(router);
app.use((error:Error,request:Request, response:Response,next:NextFunction)=>{
  return response.json({
    status:"Error",
    message:error.message
  })
})

router.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

const PORT = process.env.PORT ?? 3000;

AppDataSource.initialize()
  .then(() => {
    console.log('Database OK');
    app.listen(PORT,()=>console.log(`Server is running on port ${PORT}`));
  })
  .catch((error) => {
    console.error(error);
  });


