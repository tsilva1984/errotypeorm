import { Router } from "express";
import { CompanyController } from "../../app/controllers/CompanyController";

const router = Router();
const id_module_master_data = process.env.MODULE_MASTER_DATA
const companieController = new CompanyController();


router.get("/adm/company", companieController.getCompanies
  /*
    #swagger.tags = ['Administration-Company']
    #swagger.description = 'View a company'
    #swagger.parameters['Adm'] = {
               in: 'query',
               name:'id',
               type:'string'
           }
  */
);





export default router;