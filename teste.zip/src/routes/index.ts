import { Router } from "express";


import company from "./adm/company";

const router = Router();


router.use(company);


export { router };

