import {CompanyRepository} from '../repositories'
import { RolesRepositories } from '../repositories/roles';
import{ICompany} from '../interfaces'
import { v4 as uuid } from 'uuid';

class CompanyService {

  private companyRepository = CompanyRepository();
  private roleRepository = new RolesRepositories();

  async createCompany({ name }: ICompany) {
    if (!name) {
      throw new Error('Company name is required');
    }

    const existingCompany = await this.roleRepository.getEntityByIdentifier(this.companyRepository,'name',name) 
    const id = existingCompany ? existingCompany.id : uuid();
    const newCompany = this.companyRepository.create({ id, name });

    await this.companyRepository.save(newCompany);

    return newCompany;
  }

  async updateCompany({ id, name, active }: ICompany) {
    const existingCompany = await this.roleRepository.getEntityByIdentifier(this.companyRepository,'id',id);

    const updatedCompany = this.companyRepository.create({
      id,
      name,
      active: active !== undefined ? active : existingCompany.active,
    });

    await this.companyRepository.save(updatedCompany);

    return updatedCompany;
  }

  async deleteCompany(id: any) {
    const existingCompany = await this.roleRepository.getEntityByIdentifier(this.companyRepository,'id',id);

    const updatedCompany = this.companyRepository.create({ ...existingCompany, active: false });

    await this.companyRepository.save(updatedCompany);

    return updatedCompany;
  }

  async getCompanies({ id, active = true }: { id?: any; active?: boolean } = {}) {
    const where: Record<string, any> = {};

    if (id !== undefined) {
      where.id = id;
    }
    if (active !== undefined) {
      where.active = active;
    }

    const companies = await this.companyRepository.find({
      where,
      order: { name: 'ASC' },
    });

    return companies;
  }
}

export { CompanyService };
