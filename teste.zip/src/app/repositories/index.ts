import { AppDataSource } from '../../database/ormconfig'
import { Company } from "../entities/Company";


export const CompanyRepository = () => {
  return AppDataSource.getRepository(Company);;
};
