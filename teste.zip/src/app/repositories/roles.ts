import { Repository } from 'typeorm';

class RolesRepositories {

  public async getEntityByIdentifier<T>(repository: Repository<T>, fieldName: keyof T, identifier: any): Promise<T> {
    if (!identifier) {
      throw new Error('Identifier is required');
    }

    const where: Partial<Record<keyof T, any>> = {};
    where[fieldName] = identifier;

    const entity = await repository.findOne({
      where,
    });

    return entity;
  }

}

export { RolesRepositories };
