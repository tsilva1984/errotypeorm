interface ICompany { 
    id?: string; 
    name: string;  
    active?:boolean;
}
export default ICompany