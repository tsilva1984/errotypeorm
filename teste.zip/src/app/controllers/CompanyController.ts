import { Request, Response } from 'express'
import { CompanyService } from '../service/CompanyService'; 

const companyService = new CompanyService();

class CompanyController {


  async createCompany(request: Request, response: Response) {
    const { name } = request.body;
    const companie = await companyService.createCompany({ name });
    return response.json(companie);
  };

  async updateCompany(request: Request, response: Response) {
    const { id,name,active } = request.body;
    const module = await companyService.updateCompany({ id,name,active });
    return response.json(module);
  };

  async deleteCompany(request: Request, response: Response) {
    const { id } = request.params;
    const module = await companyService.deleteCompany(id);
    return response.json(module);
  };

  async getCompanies(request: Request, response: Response) {
    const modules = await companyService.getCompanies(request.query);
    return response.json(modules);
  };

}

export { CompanyController }