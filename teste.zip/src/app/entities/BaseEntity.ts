import { PrimaryColumn, CreateDateColumn,UpdateDateColumn,Column } from "typeorm";
import { v4 as uuid } from "uuid";

export class BaseEntity {
  @PrimaryColumn({ type: 'uuid'})
  readonly id: string;

  @Column({ type: 'boolean'})
  active: boolean;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  constructor() {
    if (!this.id) {
      this.id = uuid();
    }
  }
}
