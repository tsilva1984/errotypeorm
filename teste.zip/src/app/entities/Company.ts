import { Entity, Column } from "typeorm";
import { BaseEntity } from "./BaseEntity";

@Entity("companies")
export class Company extends BaseEntity {
  @Column({ type: 'varchar', unique: true })
  name: string;
}


