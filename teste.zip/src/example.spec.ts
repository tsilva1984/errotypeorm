import {expect,test} from 'vitest'

test ('sum two numbers',()=>{
    expect (1+3).toEqual(4)
})

